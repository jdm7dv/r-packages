library("testthat")
test_check("rplos")
